<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Data Karyawan</title>
  </head>
  <body>
    <h1>DATA KARYAWAN</h1>
    <?php foreach($karyawan as $key) {?>
    <form action="insert" method="post">
				<p class="h4 text-center py-4">Tambah Data Karyawan</p>

				<div class="md-form">
					<i class="fa fa-id-card-o prefix grey-text"></i>
					<input type="text" name="ID_Karyawan" placeholder="ID Karyawan" value="<?php echo $key->ID_Karyawan ?>">
				</div>

				<div class="md-form">
					<i class="fa fa-list-ol prefix grey-text"></i>
					<input type="text" name="Nama_Lengkap" placeholder="Nama Lengkap" value="<?php echo $key->Nama_Lengkap ?>">
				</div>
				<div class="md-form">
					<i class="fa fa-book prefix grey-text"></i>
					<input type="text" name="Jenis_Kelamin" placeholder="Jenis Kelamin" value="<?php echo $key->Jenis_Kelamin ?>">
				</div>
				<div class="md-form">
					<i class="fa fa-globe prefix grey-text"></i>
					<input type="text" name="Tanggal_Lahir" placeholder="Tanggal Lahir" value="<?php echo $key->Tanggal_Lahir ?>">
				</div>
				<div class="md-form">
					<i class="fa fa-sort-numeric-asc prefix grey-text"></i>
					<input type="text" name="Alamat_Lengkap" placeholder="Alamat Lengkap" value="<?php echo $key->Alamat_Lengkap ?>">
				</div>
				<br>
				<br><br>
				<center class="mb-3"><input type="submit" name="btnsimpan" class="btn btn-primary" value="Simpan">
					<input class="btn btn-danger" type="submit" onclick="confirms()" value="Batal"></center>
				</form>
			<?php } ?>
		</div>
	</div>
	<script type='text/javascript'>
		function confirms() {
			var answer = confirm('Ingin meninggalkan form?')
			if (answer){
				window.location = 'index';
			}
		}
	</script>
	<script type='text/javascript'>
		function keluar() {
			var kel = confirm('Ingin keluar dari akun?')
			if (kel){
				window.location = '../index.php?pesan=keluar';
			}
		}
	</script>
  </body>
</html>
