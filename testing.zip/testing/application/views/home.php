<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/styles/gaya.css">
    <title>Home</title>
</head>
<body>
    <div class="container">
        <h1>Daftar Karyawan</h1>
        <br><br>
        <button class="button" onclick="<?php echo base_url(); ?>testing/insertKaryawan">Tambah Data Karyawan</button>
        <br><br>
        <table class="table table-bordered">
            <thead>
                <th>ID Karyawan</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Keterangan</th>
            </thead>
            <tbody>
                <?php foreach($karyawan as $karyawan): ?>
                    <tr>
                        <td><?= $karyawan -> ID_Karyawan; ?></td>
                        <td><?= $karyawan -> Nama_Lengkap; ?></td>
                        <td><?= $karyawan -> Jenis_Kelamin; ?></td>
                        <td><?= $karyawan -> Tanggal_Lahir; ?></td>
                        <td><?= $karyawan -> Alamat_Lengkap; ?></td>
                        <td><button class="button">Edit</button><button class="button">Hapus</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
</body>
</html>
