<?php
class testing extends CI_controller {
    public function index() {
        $this -> load -> model('karyawan_model');
        $karyawan = $this -> karyawan_model -> getKaryawan();
        $data['karyawan'] = $karyawan;
        $this -> load -> view('home', $data);
    }

    public function profile($id) {
        $this -> load -> model('karyawan_model');
        $karyawan = $this -> karyawan_model -> getProfil($id);
        var_dump($karyawan);
    }

    public function insertKaryawan() {
      $this -> load -> view('insertKaryawan');
    }

}
