<?php

class karyawan_model extends CI_Model {
  public function getKaryawan(){
    $this -> load -> database();
    $query = "SELECT * FROM karyawan";
    $result_test = $this -> db -> query($query);
    $karyawan = $result_test -> result();
    return $karyawan;
  }

  public function getProfil($id) {
        $this -> load -> database();
        $query = "SELECT * FROM karyawan WHERE ID_KARYAWAN=" . $id;
        $result_test = $this -> db -> query($query);
        return $result_test->row();
    }

    public function insertKaryawan(){
        $this -> load -> database();
        $data = array(
            "ID_Karyawan" => $this -> input -> post ('ID_Karyawan'),
            "Nama_Lengkap" => $this -> input -> post ('Nama_Lengkap'),
            "Jenis_Kelamin" => $this -> input -> post('Jenis_Kelamin'),
            "Tanggal_Lahir" => $this -> input -> post('Tanggal_Lahir'),
            "Alamat_Lengkap" => $this -> input -> post('Alamat_Lengkap')
        );
        return $this -> db -> insert('karyawan', $data);
    }

        public function update($isbn =''){
    		$data = array(
    			'idpgr' => $this->input->post('$idpgr'),
    			'kodebk' => $this->input->post('$kodebk'),
    			'judul' => $this->input->post('$judul'),
    			'kota' => $this->input->post('$kota'),
    			'tahun' => $this->input->post('$tahun'),
    			'stokbk' => $this->input->post('$stokbk'),
    			'hargabk' => $this->input->post('$hargabk')
    		);
    		$this->db->where('isbn', $isbn);
    		$this->db->update('buku', $data);

    		$this->load->helper('url');
    		redirect('buku','refresh');
    	}

      public function hapusbuku($isbn){
    		$where = array('isbn' => $isbn);
    		$res = $this->mymodel->DeleteData('buku',$where);
    		if($res>=1){
    			$this->load->helper('url');
    			redirect('buku/index');
    		}
    	}
}
 ?>
